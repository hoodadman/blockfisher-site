// src/keys.ts
async function loadKeys() {
  const stored = await chrome.storage.local.get(["insightx", "twitter"]);
  return {
    insightx: typeof stored.insightx === "string" ? stored.insightx.trim() : void 0,
    twitter: typeof stored.twitter === "string" ? stored.twitter.trim() : void 0
  };
}

// ../trust-score-saved/src/adapters/util.ts
function compact(signals) {
  return Object.fromEntries(Object.entries(signals).filter(([, value]) => value !== void 0));
}
var isNumber = (value) => typeof value === "number" && Number.isFinite(value);
function anyTrue(...flags) {
  if (flags.some((flag2) => flag2 === true)) return true;
  return flags.every((flag2) => flag2 === false) ? false : void 0;
}

// ../trust-score-saved/src/adapters/dexscreener.ts
function signalsFromDexScreener(pairs) {
  if (pairs.length === 0) return {};
  const liquidity = pairs.map((pair) => pair.liquidity?.usd).filter(isNumber);
  const created = pairs.map((pair) => pair.pairCreatedAt).filter(isNumber);
  return compact({
    liquidityUsd: liquidity.length ? Math.max(...liquidity) : void 0,
    launchedAt: created.length ? Math.min(...created) : void 0,
    hasWebsiteOrSocials: pairs.some((pair) => (pair.info?.websites?.length ?? 0) + (pair.info?.socials?.length ?? 0) > 0)
  });
}
function tokenFromDexScreener(pairs, address) {
  const wanted = address.toLowerCase();
  for (const pair of pairs) {
    const token = [pair.baseToken, pair.quoteToken].find((side) => side?.address?.toLowerCase() === wanted);
    if (token) return { name: token.name, symbol: token.symbol };
  }
  return {};
}
var HANDLE = /^[A-Za-z0-9_]{1,15}$/;
function twitterHandleFromDexScreener(pairs) {
  for (const pair of pairs) {
    for (const social of pair.info?.socials ?? []) {
      const handle = handleFromSocial(social);
      if (handle) return handle;
    }
  }
  return void 0;
}
function handleFromSocial(social) {
  const kind = (social.type ?? social.platform ?? "").toLowerCase();
  if (kind && kind !== "twitter" && kind !== "x") return void 0;
  const fromField = social.handle?.replace(/^@/, "").trim();
  if (fromField && HANDLE.test(fromField)) return fromField;
  return handleFromUrl(social.url);
}
function websitesFromDexScreener(pairs) {
  const urls = /* @__PURE__ */ new Set();
  for (const pair of pairs) {
    for (const site of pair.info?.websites ?? []) {
      const url = typeof site === "string" ? site : site && typeof site === "object" && "url" in site ? String(site.url ?? "") : "";
      if (url.startsWith("http")) urls.add(url);
    }
  }
  return [...urls];
}
function handleFromUrl(url) {
  if (!url) return void 0;
  try {
    const parsed = new URL(url);
    if (!/^(www\.)?(twitter|x)\.com$/i.test(parsed.hostname)) return void 0;
    const [first] = parsed.pathname.split("/").filter(Boolean);
    if (!first || ["i", "intent", "share", "search", "home"].includes(first.toLowerCase())) return void 0;
    const handle = first.replace(/^@/, "");
    return HANDLE.test(handle) ? handle : void 0;
  } catch {
    return void 0;
  }
}

// ../trust-score-saved/src/adapters/goplus.ts
var ZERO = "0x0000000000000000000000000000000000000000";
var DEAD = "0x000000000000000000000000000000000000dead";
function flag(value) {
  if (value === "1") return true;
  if (value === "0") return false;
  return void 0;
}
function taxPct(value) {
  if (value === void 0 || value === "") return void 0;
  const number = Number(value);
  if (!Number.isFinite(number)) return void 0;
  return number <= 1 ? number * 100 : number;
}
function ownerGaveUp(address) {
  if (address === void 0) return void 0;
  const normalised = address.toLowerCase();
  return normalised === "" || normalised === ZERO || normalised === DEAD;
}
function lockedLiquidityPct(holders) {
  if (!holders?.length) return void 0;
  const locked = holders.reduce((sum, holder) => {
    if (holder.is_locked !== 1) return sum;
    const share = Number(holder.percent);
    return isNumber(share) ? sum + share * 100 : sum;
  }, 0);
  return Math.min(100, locked);
}
function tokenFromGoPlus(result, address) {
  if (!result) return void 0;
  return result[address] ?? result[address.toLowerCase()];
}
function signalsFromGoPlus(chainId, token) {
  if (chainId === "solana") {
    const t2 = token;
    const fee = t2.transfer_fee?.current_fee_rate;
    return compact({
      honeypotRisk: flag(t2.non_transferable) === void 0 ? void 0 : flag(t2.non_transferable) ? 100 : 0,
      mintable: flag(t2.mintable?.status),
      canFreeze: flag(t2.freezable?.status),
      canTakeTokens: anyTrue(flag(t2.closable?.status), flag(t2.balance_mutable_authority?.status)),
      feesChangeable: flag(t2.transfer_fee_upgradable?.status),
      metadataMutable: flag(t2.metadata_mutable?.status),
      transferFeePct: taxPct(fee)
    });
  }
  const t = token;
  const honeypot = flag(t.is_honeypot);
  const hiddenControl = anyTrue(flag(t.hidden_owner), flag(t.can_take_back_ownership));
  const ownershipRenounced = ownerGaveUp(t.owner_address);
  const stillInControl = ownershipRenounced === true && hiddenControl === false ? false : true;
  const ifOwner = (value) => value === void 0 ? void 0 : stillInControl && value;
  return compact({
    honeypotRisk: honeypot === void 0 ? void 0 : honeypot ? 100 : 0,
    canTakeTokens: ifOwner(flag(t.owner_change_balance)),
    knownScamCreator: flag(t.honeypot_with_same_creator),
    canPause: ifOwner(flag(t.transfer_pausable)),
    buyFeePct: taxPct(t.buy_tax),
    sellFeePct: taxPct(t.sell_tax),
    transferFeePct: taxPct(t.transfer_tax),
    feesChangeable: ifOwner(anyTrue(flag(t.slippage_modifiable), flag(t.personal_slippage_modifiable))),
    mintable: ifOwner(flag(t.is_mintable)),
    canFreeze: ifOwner(anyTrue(flag(t.is_blacklisted), flag(t.is_whitelisted))),
    hasBlacklist: ifOwner(flag(t.is_blacklisted)),
    hasWhitelist: ifOwner(flag(t.is_whitelisted)),
    codeVerified: flag(t.is_open_source),
    upgradeable: flag(t.is_proxy),
    hiddenControl,
    sellLimited: ifOwner(flag(t.cannot_sell_all)),
    cannotSellAll: ifOwner(flag(t.cannot_sell_all)),
    antiWhale: ifOwner(anyTrue(flag(t.anti_whale_modifiable), flag(t.is_anti_whale))),
    tradingCooldown: ifOwner(flag(t.trading_cooldown)),
    externalCall: flag(t.external_call),
    suspiciousFunctions: flag(t.selfdestruct),
    ownershipRenounced,
    liquidityLockedPct: lockedLiquidityPct(t.lp_holders)
  });
}

// ../trust-score-saved/src/adapters/insightx.ts
var chainFromNetwork = (network) => network === "sol" ? "solana" : "evm";
function signalsFromInsightXDexMetrics(network, metrics) {
  const onSolana = network === "sol";
  return compact({
    clusterPct: metrics.cluster_pct,
    top10Pct: metrics.top10_pct,
    snipersPct: onSolana ? metrics.snipers_pct : void 0,
    bundlersPct: onSolana ? metrics.bundlers_pct : void 0,
    devPct: onSolana ? metrics.dev_pct : void 0,
    insidersPct: onSolana ? metrics.insiders_pct : void 0
  });
}

// ../trust-score-saved/src/adapters/coingecko.ts
function exchangeIdsFromCoinGecko(coin) {
  const ids = /* @__PURE__ */ new Set();
  for (const ticker of coin.tickers ?? []) {
    const raw = `${ticker.market?.identifier ?? ""} ${ticker.market?.name ?? ""}`.toLowerCase();
    if (raw.trim()) ids.add(raw);
  }
  return [...ids];
}

// ../trust-score-saved/src/adapters/index.ts
var GOPLUS_CHAIN = {
  eth: "1",
  base: "8453",
  bsc: "56",
  sol: "solana"
};
var goPlusChainId = (network) => GOPLUS_CHAIN[network];
function buildSignals(network, sources) {
  return {
    chain: chainFromNetwork(network),
    ...sources.dexScreenerPairs && signalsFromDexScreener(sources.dexScreenerPairs),
    ...sources.goPlus && signalsFromGoPlus(goPlusChainId(network), sources.goPlus),
    ...sources.insightXDexMetrics && signalsFromInsightXDexMetrics(network, sources.insightXDexMetrics)
  };
}

// ../trust-score-saved/src/community/score.ts
var MIN_FOLLOWERS = 10;
var ACTIVITY_BANDS = [
  { band: "active", min: 70 },
  { band: "warming", min: 40 },
  { band: "quiet", min: 0 }
];
function clamp(value, max) {
  return Math.max(0, Math.min(max, value));
}
function average(values) {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}
function followerPoints(followers, max = 30) {
  if (followers < MIN_FOLLOWERS) return 0;
  return clamp((Math.log10(followers) - 1) * 10, max);
}
function replyPoints(averageReplies) {
  return clamp(Math.log10(1 + averageReplies) * 12, 20);
}
function likePoints(averageLikes) {
  return clamp(Math.log10(1 + averageLikes) * 6, 12);
}
function repostPoints(averageReposts) {
  return clamp(Math.log10(1 + averageReposts) * 5, 8);
}
function mentionWeight(mention) {
  if (mention.followers < MIN_FOLLOWERS) return 0;
  const size = Math.log10(mention.followers);
  const buzz = 1 + mention.replies / 5 + mention.likes / 20 + mention.reposts / 10;
  return size * buzz;
}
function mentionPoints(weights) {
  const total = weights.reduce((sum, value) => sum + value, 0);
  return clamp(Math.log10(1 + total) * 14, 30);
}
function scoreCommunity(input) {
  const official = summariseOfficial(input.official);
  const mentions = summariseMentions(input.mentions ?? []);
  const fromPage = official ? followerPoints(official.followers) + replyPoints(official.averageReplies) + likePoints(official.averageLikes) + repostPoints(official.averageReposts) : 0;
  const fromMentions = mentionPoints(
    (input.mentions ?? []).map(mentionWeight).filter((weight) => weight > 0)
  );
  const raw = official ? fromPage + fromMentions : Math.min(40, fromMentions);
  const hasAnything = Boolean(official) || mentions.counted > 0;
  const score = hasAnything ? Math.round(clamp(raw, 100)) : null;
  const band = score === null ? null : ACTIVITY_BANDS.find(({ min }) => score >= min)?.band ?? "quiet";
  return { score, band, official, mentions };
}
function summariseOfficial(page) {
  if (!page) return void 0;
  const tweets = page.tweets;
  return {
    handle: page.handle,
    name: page.name,
    followers: page.followers,
    tweetsLookedAt: tweets.length,
    averageLikes: average(tweets.map((tweet) => tweet.likes)),
    averageReplies: average(tweets.map((tweet) => tweet.replies)),
    averageReposts: average(tweets.map((tweet) => tweet.reposts))
  };
}
function summariseMentions(mentions) {
  let counted = 0;
  let ignoredBots = 0;
  let weightedReach = 0;
  for (const mention of mentions) {
    const weight = mentionWeight(mention);
    if (weight === 0) ignoredBots += 1;
    else {
      counted += 1;
      weightedReach += weight;
    }
  }
  return { counted, ignoredBots, weightedReach };
}

// ../trust-score-saved/src/foundation/score.ts
var HOUR = 36e5;
var PRESALE_MIN = 1e7;
var KNOWN_PERSON = 1e4;
var MAJOR_EXCHANGES = [
  { id: "binance", label: "Binance", match: /\bbinance\b/i },
  { id: "coinbase", label: "Coinbase", match: /\bcoinbase\b|\bgdax\b/i }
];
var OTHER_EXCHANGES = [
  { id: "kraken", label: "Kraken", match: /\bkraken\b/i },
  { id: "okx", label: "OKX", match: /\bokx\b|\bokex\b/i },
  { id: "bybit", label: "Bybit", match: /\bbybit\b/i },
  { id: "upbit", label: "Upbit", match: /\bupbit\b/i },
  { id: "kucoin", label: "KuCoin", match: /\bkucoin\b/i },
  { id: "bitfinex", label: "Bitfinex", match: /\bbitfinex\b/i },
  { id: "gemini", label: "Gemini", match: /\bgemini\b/i },
  { id: "crypto.com", label: "Crypto.com", match: /crypto\.com/i }
];
var INVESTORS = [
  { id: "binance-labs", label: "Binance Labs", match: /binance\s*labs/i },
  { id: "coinbase-ventures", label: "Coinbase Ventures", match: /coinbase\s*ventures/i },
  { id: "a16z", label: "a16z", match: /\ba16z\b|andreessen/i },
  { id: "paradigm", label: "Paradigm", match: /\bparadigm\b/i },
  { id: "sequoia", label: "Sequoia", match: /\bsequoia\b/i },
  { id: "pantera", label: "Pantera", match: /\bpantera\b/i },
  { id: "jump", label: "Jump Crypto", match: /\bjump\s*(crypto|trading)?\b/i },
  { id: "circle", label: "Circle", match: /\bcircle\b/i },
  { id: "animoca", label: "Animoca", match: /\banimoca\b/i },
  { id: "polychain", label: "Polychain", match: /\bpolychain\b/i },
  { id: "dragonfly", label: "Dragonfly", match: /\bdragonfly\b/i },
  { id: "multicoin", label: "Multicoin", match: /\bmulticoin\b/i },
  { id: "hashed", label: "Hashed", match: /\bhashed\b/i },
  { id: "wintermute", label: "Wintermute", match: /\bwintermute\b/i }
];
var DOCS = /whitepaper|litepaper|gitbook|\/docs(?:\/|$)|docs\.|notion\.site|github\.com/i;
var DOCS_WORD = /white\s*paper|lite\s*paper|documentation/i;
var RAISE = /(?:presale|pre-sale|raised|raise|funding)\D{0,24}\$?\s*(\d+(?:\.\d+)?)\s*(k|m|b|million|billion)\b|\b\$\s*(\d+(?:\.\d+)?)\s*(k|m|b|million|billion)\b(?:\s+(?:presale|pre-sale|raised|raise))?/i;
function clamp2(value, max = 100) {
  return Math.max(0, Math.min(max, value));
}
function labelsFrom(list, text) {
  return list.filter((item) => item.match.test(text)).map((item) => item.label);
}
function parseRaiseUsd(text) {
  const match = text.match(RAISE);
  if (!match) return void 0;
  const amount = Number(match[1] ?? match[3]);
  const unit = (match[2] ?? match[4] ?? "").toLowerCase();
  if (!Number.isFinite(amount)) return void 0;
  const scale = unit.startsWith("b") ? 1e9 : unit.startsWith("m") ? 1e6 : 1e3;
  return amount * scale;
}
function findDocsUrl(urls, bio = "") {
  const hit = urls.find((url) => DOCS.test(url));
  if (hit) return hit;
  return DOCS_WORD.test(bio) ? urls[0] : void 0;
}
function agePoints(hours) {
  if (hours === void 0) {
    return {
      points: 0,
      fact: {
        id: "age",
        label: "How old it is",
        status: "unknown",
        summary: "We don\u2019t know when this token started trading.",
        details: "Older tokens have a longer public history. Brand-new ones are harder to judge, because there has been less time for problems to show up."
      }
    };
  }
  const days = hours / 24;
  const points = hours < 24 ? 3 : hours < 7 * 24 ? 6 : hours < 30 * 24 ? 11 : hours < 180 * 24 ? 16 : hours < 365 * 24 ? 20 : 25;
  const status = points >= 20 ? "good" : points >= 11 ? "mid" : "bad";
  const when = days < 2 ? "less than 2 days" : days < 14 ? `${Math.floor(days)} days` : `${Math.floor(days / 30)} months`;
  return {
    points,
    fact: {
      id: "age",
      label: "How old it is",
      status,
      summary: `It has been trading for ${when}.`,
      details: "A longer trading history doesn\u2019t make a token safe, but it does mean more people have had time to spot problems. Very new tokens are easier to fake."
    }
  };
}
function backingPoints(people) {
  const known = people.filter((person) => person.followers >= KNOWN_PERSON);
  const named = people.filter((person) => person.followers < KNOWN_PERSON);
  let points = 0;
  if (known.length) points += Math.min(15, 10 + (known.length - 1) * 3);
  else if (named.length) points += 5;
  let status = "unknown";
  let summary = "We didn\u2019t find a named person on the official page.";
  if (known.length) {
    status = "good";
    summary = `The official page points to @${known[0].handle}.`;
  } else if (named.length) {
    status = "mid";
    summary = `The official page names @${named[0].handle}, but that account is not well known.`;
  }
  return {
    points,
    fact: {
      id: "backing",
      label: "Who backs it",
      status,
      summary,
      details: "We read the official Twitter bio for @mentions of real people. A named, established person is a better sign than an anonymous page. It is still not a guarantee."
    }
  };
}
function docsPoints(docsUrl, bio) {
  if (docsUrl) {
    return {
      points: 15,
      fact: {
        id: "docs",
        label: "Documentation",
        status: "good",
        summary: "We found a public write-up, such as a white paper or docs page.",
        details: "A public document that explains how the token works is a basic sign of a real project. Anyone can publish a document, so this is not a safety check on its own."
      }
    };
  }
  if (DOCS_WORD.test(bio)) {
    return {
      points: 5,
      fact: {
        id: "docs",
        label: "Documentation",
        status: "mid",
        summary: "The bio mentions a white paper or docs, but we couldn\u2019t open a clear link.",
        details: "The page talks about documentation, but we didn\u2019t find a working link."
      }
    };
  }
  return {
    points: 0,
    fact: {
      id: "docs",
      label: "Documentation",
      status: "unknown",
      summary: "We didn\u2019t find a white paper or docs page.",
      details: "Many serious projects publish a short public document explaining the token. Missing docs is common, and not always a warning by itself."
    }
  };
}
function fundingPoints(input) {
  const hintText = input.exchangeHints.join("\n");
  const majors = [.../* @__PURE__ */ new Set([...labelsFrom(MAJOR_EXCHANGES, input.text), ...labelsFrom(MAJOR_EXCHANGES, hintText)])];
  const others = [.../* @__PURE__ */ new Set([...labelsFrom(OTHER_EXCHANGES, input.text), ...labelsFrom(OTHER_EXCHANGES, hintText)])];
  const investors = labelsFrom(INVESTORS, input.text);
  const presaleUsd = parseRaiseUsd(input.text);
  let points = 0;
  if (majors.includes("Binance")) points += 40;
  if (majors.includes("Coinbase")) points += 40;
  if (others.length) points += Math.min(20, 12 + (others.length - 1) * 6);
  if (presaleUsd !== void 0 && presaleUsd >= PRESALE_MIN) points += 25;
  if (investors.length) points += Math.min(20, 15 + (investors.length - 1) * 5);
  points = clamp2(points, 45);
  const exchanges = [...majors, ...others];
  let status = "unknown";
  let summary = "We didn\u2019t find a large raise, a well-known investor, or a listing on a major exchange.";
  if (majors.length) {
    status = "good";
    summary = `It is listed on ${majors.join(" and ")}.`;
  } else if (presaleUsd !== void 0 && presaleUsd >= PRESALE_MIN) {
    status = "good";
    summary = `It raised about $${Math.round(presaleUsd / 1e6)}m before launch.`;
  } else if (investors.length) {
    status = "good";
    summary = `Known backers include ${investors[0]}.`;
  } else if (others.length) {
    status = "mid";
    summary = `It is listed on ${others[0]}, which is a known exchange but not one of the largest.`;
  } else if (presaleUsd !== void 0) {
    status = "mid";
    summary = `We found a raise figure, but it is below $10m.`;
  }
  return {
    points,
    exchanges,
    investors,
    presaleUsd,
    fact: {
      id: "funding",
      label: "Funding",
      status,
      summary,
      details: "A listing on Binance or Coinbase counts the most. A presale above $10m, or a well-known investor such as Binance Labs, also helps. This is still not a promise that the token is safe."
    }
  };
}
function scoreFoundation(input) {
  const now = input.now ?? Date.now();
  const hours = input.launchedAt === void 0 ? void 0 : (now - input.launchedAt) / HOUR;
  const text = [input.bio, ...input.urls ?? [], ...input.websites ?? []].filter(Boolean).join("\n");
  const urls = [...input.urls ?? [], ...input.websites ?? []];
  const docsUrl = findDocsUrl(urls, input.bio ?? "");
  const people = input.mentionedPeople ?? [];
  const age = agePoints(hours);
  const backing = backingPoints(people);
  const docs = docsPoints(docsUrl, input.bio ?? "");
  const funding = fundingPoints({ text, exchangeHints: input.exchangeHints ?? [] });
  const facts = [age.fact, backing.fact, docs.fact, funding.fact];
  const known = age.points + backing.points + docs.points + funding.points;
  const hasAny = hours !== void 0 || Boolean(input.bio) || urls.length > 0 || people.length > 0 || (input.exchangeHints?.length ?? 0) > 0;
  const score = hasAny ? Math.round(clamp2(known)) : null;
  const band = score === null ? null : score >= 70 ? "solid" : score >= 40 ? "forming" : "thin";
  return {
    score,
    band,
    facts,
    backers: people,
    brands: [...funding.exchanges, ...funding.investors],
    docsUrl,
    exchanges: funding.exchanges,
    investors: funding.investors,
    presaleUsd: funding.presaleUsd
  };
}

// ../trust-score-saved/src/scoring/glossary.ts
var GLOSSARY = {
  feesChangeable: {
    term: "Tax modifiable",
    userFriendly: "The creator can change the buy or sell fee after the token is launched.",
    risk: "They could raise the sell fee so high that you are stuck, or only leave at a heavy loss.",
    technical: "Smart contract contains privileged setter functions that permit admin addresses to manipulate fee state variables post-deployment.",
    source: "Initial concepts have been expanded from CertiK Token Scan parameters."
  },
  externalCall: {
    term: "External call",
    userFriendly: "While a normal transfer is happening, the token can run outside code that is not part of the token itself.",
    risk: "That outside code could steal funds, block the transfer, or change the token mid-transaction.",
    technical: "The contract executes external instructions during execution flows, handing temporary control flow and execution context to an external contract address.",
    source: "Initial concepts have been expanded from CertiK Token Scan parameters."
  },
  ownership: {
    term: "Ownership renounced",
    userFriendly: "We check whether the original creator has given up owner status, so they can no longer use admin tools.",
    risk: "If they still own it, they may still pause trading, mint tokens, or change fees. If they have given it up, bugs in the code can never be patched.",
    technical: "The smart contract state variable for the contract owner address has been permanently set to a zero or burn address, therefore revoking access to functions protected by administrative access-control modifiers.",
    source: "Initial concepts have been expanded from CertiK Token Scan parameters."
  },
  hiddenControl: {
    term: "Hidden owner",
    userFriendly: "Someone may still have admin control even though a normal ownership check looks clean.",
    risk: "The token can look safe because ownership appears given up, while a hidden controller can still change fees, block sales, mint tokens, or drain the trading pot.",
    technical: "The smart contract utilises indirect access-control mechanisms that allow a specific address to bypass standard owner limitations and execute privileged functions.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken context."
  },
  publicCode: {
    term: "Open source",
    userFriendly: "The token\u2019s code should be public, so the risks can actually be checked.",
    risk: "If the code is not public, the other checks cannot be trusted with certainty.",
    technical: "The contract bytecode deployed on-chain matches verified, human-readable source code compiled and submitted to a public block explorer.",
    source: "Initial concepts have been expanded from CertiK Token Scan."
  },
  honeypot: {
    term: "Honeypot",
    userFriendly: "You can buy the token, but selling is blocked, restricted, or extremely expensive.",
    risk: "Your money is usually stuck. The price may keep rising as others buy in, until the creator drains the trading pot.",
    technical: "Smart contract logic containing conditional trade execution barriers that permit buy functions while sell functions fail or revert.",
    source: "Initial concepts have been expanded from CertiK published blog and SlowMist."
  },
  upgradeable: {
    term: "Proxy contract",
    userFriendly: "The creator can later swap the rules for a completely different set of rules.",
    risk: "A token that looks safe today can be changed into a honeypot, or have balances rewritten, without you doing anything.",
    technical: "A setup where a proxy contract holds the token\u2019s data but forwards execution to a separate contract. The proxy address stays the same, but an admin can point it at brand-new code.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken context."
  },
  mintable: {
    term: "Mintable",
    userFriendly: "The creator can increase the supply, so each existing token is worth a smaller share.",
    risk: "They can print new tokens and sell them into the pool, which can collapse the price.",
    technical: "The smart contract contains state-increasing functions protected by access-control modifiers. These functions allow admin addresses to increase the total supply and assign newly created tokens to arbitrary wallet addresses after deployment.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken context."
  },
  pause: {
    term: "Transfer pausable",
    userFriendly: "The creator can freeze all transfers, so buying, selling, or sending the token becomes impossible.",
    risk: "Your tokens can be stuck until they choose to switch trading back on \u2014 if they ever do.",
    technical: "The smart contract incorporates an emergency stop mechanism where transfer functions are affected. Designated admin roles can trigger pause and unpause functions restricting core transfer methods.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken."
  },
  tradingCooldown: {
    term: "Trading cooldown",
    userFriendly: "The creator can force a wait between buys, sells, or transfers, and can stretch that wait.",
    risk: "In a fast-moving market, even a short lock can mean a large loss. A longer cooldown can trap wallets.",
    technical: "The smart contract tracks time parameters for individual wallet addresses or globally within transfer functions. A conditional check enforces a mandatory delay between consecutive executions, and privileged admin roles can reconfigure it.",
    source: "Initial concepts have been expanded from CertiK Token Scan and SlowMist."
  },
  sellLimits: {
    term: "Can\u2019t sell all",
    userFriendly: "You may have to keep a minimum balance, so you can never sell your whole holding.",
    risk: "You stay exposed to the price, and in a rug pull that leftover amount can become worthless.",
    technical: "Smart contract transfer functions include a conditional check that evaluates a wallet\u2019s remaining balance after a sell order. If the post-transaction balance drops below a required minimum, the transaction reverts.",
    source: "Initial concepts have been expanded from CertiK Token Scan."
  },
  canTakeTokens: {
    term: "Owner can change balance",
    userFriendly: "The creator can change any wallet\u2019s balance without that person\u2019s say-so.",
    risk: "They can zero your balance and take the tokens without a normal transfer.",
    technical: "The smart contract exposes privileged setter functions that directly manipulate the balances mapping for specific address keys, allowing designated admin roles to set, increase, or reset user token balances without standard transfer logs or user signatures.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken context."
  },
  hasBlacklist: {
    term: "Has blacklist",
    userFriendly: "The creator can lock a chosen wallet out of buying, selling, or sending.",
    risk: "Your wallet can be blocked with no notice, in a single transaction.",
    technical: "The smart contract maintains a mapping of addresses to boolean values controlled by administrative functions. Core transfer methods revert if initiated by or routed to a flagged address.",
    source: "Initial concepts have been expanded from CertiK Token Scan and SlowMist."
  },
  hasWhitelist: {
    term: "Has whitelist",
    userFriendly: "Some wallets \u2014 usually the creator\u2019s \u2014 can skip taxes, trade while others are paused, or sell before the public can.",
    risk: "They can sell freely while you cannot, so the market is stacked against ordinary holders.",
    technical: "The smart contract maintains a mapping of addresses to boolean status flags managed via administrative functions. Core transfer methods check these states to bypass fees, cooldowns, or a global pause for designated addresses.",
    source: "Initial concepts have been expanded from CertiK Token Scan and SlowMist."
  },
  fees: {
    term: "Buy and sell tax",
    userFriendly: "A buy tax takes a cut when you purchase. A sell tax takes a cut when you exit. The creator should disclose a fixed rate.",
    risk: "A high or hidden fee shrinks what you receive. If they can also change it later, the fee can become a trap.",
    technical: "Transfer functions calculate a percentage fee when a buy or sell swap is detected against a decentralised exchange pair, then redirect that portion before completing the trade.",
    source: "Initial concepts have been expanded from CertiK Token Scan and Hacken context."
  },
  antiWhale: {
    term: "Is anti-whale",
    userFriendly: "The creator can cap how much anyone may buy, sell, or hold \u2014 and usually exempt their own wallets.",
    risk: "Rules they can change at will can be used to limit how much you can buy or how fast you can sell, while they trade freely.",
    technical: "Transfer functions contain conditional checks enforcing maximum transaction limits or maximum wallet balance thresholds. Transactions over those limits revert, while admin or whitelisted addresses are bypassed.",
    source: "Initial concepts have been expanded from CertiK Token Scan."
  },
  topHolders: {
    term: "Holder count",
    userFriendly: "Holder spread shows whether many people own the token, or only a few wallets do.",
    risk: "If most of the supply sits with the creator or a handful of wallets, one sale can crash the price.",
    technical: "An off-chain indexed metric of unique non-zero balance addresses for the contract, excluding pool, burn, and bridge accounts.",
    source: "Initial concepts have been expanded from CertiK Token Scan."
  },
  knownScamCreator: {
    term: "Creator address",
    userFriendly: "We check whether the creator\u2019s wallet is linked to other scam tokens.",
    risk: "A wallet tied to earlier scams, especially if it can still mint, pause, or block selling, is a serious warning.",
    technical: "A cross-reference against other known scam deployments. A single deploying address that controls minting, pausing, or blacklisting is a systematic governance risk. A link to another scam does not prove this token is a scam, but it warrants extra caution.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken context."
  },
  devHoldings: {
    term: "Creator balance",
    userFriendly: "This is how much of the supply the owner or creator still holds.",
    risk: "A large unlocked holding can be dumped on the market. That is worse if they can still mint, or have not given up ownership.",
    technical: "Percentage of supply held by the creator. Unlike locked liquidity, there is no selling restriction. Combined with a mintable contract or non-renounced ownership, this can indicate a pump and dump.",
    source: "Initial concepts have been expanded from CertiK Token Scan."
  },
  obfuscated: {
    term: "Has obfuscated address",
    userFriendly: "The contract cannot be fully verified, so a complete security check was impossible.",
    risk: "We cannot be sure the contract is safe.",
    technical: "Closed-source code, proxy redirection, or hidden-owner mechanics can hide what functions exist, what triggers them, and who controls them.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken context."
  },
  suspiciousFunctions: {
    term: "Has suspicious functions",
    userFriendly: "The contract has potentially malicious functions, or the owner has more control than they should.",
    risk: "They may be able to block wallets, drain balances, or change how transfers work after launch.",
    technical: "Self-destruct, hidden mint, external calls, balance modifications, and ownership retrievals may be hidden. Contract behaviour may deviate from expected ERC-20 behaviour.",
    source: "Initial concepts have been expanded from CertiK Token Scan and supporting Hacken context."
  },
  canFreeze: {
    term: "Has blacklist",
    userFriendly: "The creator can lock a wallet so those tokens cannot be sold or sent.",
    risk: "Your wallet can be frozen with no notice.",
    technical: "A freeze authority or blacklist mapping lets an admin stop chosen addresses from transferring.",
    source: "Initial concepts have been expanded from CertiK Token Scan and SlowMist."
  },
  liquidityLock: {
    term: "Locked trading pool",
    userFriendly: "We check how much of the shared pot used for trading is locked so it cannot be pulled out.",
    risk: "If most of the pot is unlocked, the creator can empty it and leave holders unable to sell at a fair price.",
    technical: "Share of LP tokens marked as locked in holder lists.",
    source: ""
  },
  liquidity: {
    term: "Trading pool size",
    userFriendly: "This is how much money sits in the shared pot used for buying and selling.",
    risk: "A tiny pot makes selling harder and more expensive, and a modest sale can crash the price.",
    technical: "Reported USD liquidity of the deepest pool.",
    source: ""
  },
  tokenAge: {
    term: "Token age",
    userFriendly: "Newer tokens have less history, so there is less to judge them by.",
    risk: "Many scams happen in the first hours or days after launch.",
    technical: "Time since the earliest pair was created.",
    source: ""
  },
  socials: {
    term: "Website and social media",
    userFriendly: "A public website or social page is a basic sign that someone is standing behind the project.",
    risk: "Missing links make the people behind the token harder to check.",
    technical: "Presence of a website or social URL on the market listing.",
    source: ""
  },
  clusters: {
    term: "Linked wallets",
    userFriendly: "We look for groups of wallets that seem to belong to the same people.",
    risk: "A large group can sell together and dump the price.",
    technical: "Clustered share of supply from shared funding or trading patterns.",
    source: ""
  },
  bundlers: {
    term: "Coordinated buying",
    userFriendly: "We look for people who bought with many wallets at once at launch.",
    risk: "That can hide a single large buyer who later dumps.",
    technical: "Share of supply bought in bundled launch transactions.",
    source: ""
  },
  snipers: {
    term: "Launch snipers",
    userFriendly: "We look for wallets that bought in the first seconds, often bots.",
    risk: "They can sell into later buyers and knock the price down.",
    technical: "Share of supply still held by first-block or first-minute buyers.",
    source: ""
  },
  metadataMutable: {
    term: "Name and logo",
    userFriendly: "The creator can still change the token\u2019s name, symbol, and picture.",
    risk: "That can be used to make this token look like a different, better-known one.",
    technical: "Metadata update authority is still held.",
    source: ""
  }
};
function tooltipFor(id) {
  const entry = GLOSSARY[id];
  if (!entry) return "";
  return `${entry.userFriendly} ${entry.risk}`;
}

// ../trust-score-saved/src/scoring/about.ts
var ABOUT = Object.fromEntries(
  Object.keys(GLOSSARY).map((id) => [id, tooltipFor(id)])
);

// ../trust-score-saved/src/scoring/checks.ts
var HOUR2 = 36e5;
function atLeast(value, rules) {
  if (value === void 0) return void 0;
  return rules.find(([min]) => value >= min)?.[1] ?? null;
}
function below(value, rules) {
  if (value === void 0) return void 0;
  return rules.find(([max]) => value < max)?.[1] ?? null;
}
function whenTrue(flag2, tier) {
  if (flag2 === void 0) return void 0;
  return flag2 ? tier : null;
}
function whenFalse(flag2, tier) {
  return whenTrue(flag2 === void 0 ? void 0 : !flag2, tier);
}
function sumDefined(...values) {
  const known = values.filter((v) => v !== void 0);
  return known.length ? known.reduce((a, b) => a + b, 0) : void 0;
}
function highestFee(s) {
  const fees = [s.buyFeePct, s.sellFeePct, s.transferFeePct].filter((f) => f !== void 0);
  return fees.length ? Math.max(...fees) : void 0;
}
function ageInHours(s, now) {
  return s.launchedAt === void 0 ? void 0 : (now - s.launchedAt) / HOUR2;
}
var percent = (value) => `${Number(value.toFixed(1))}%`;
var dollars = (value) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value);
function describeFee(s) {
  const top = highestFee(s) ?? 0;
  if (s.transferFeePct === top) return `${percent(top)} on every transfer`;
  if (s.buyFeePct === top && s.sellFeePct === top) return `${percent(top)} when you buy or sell`;
  return `${percent(top)} when you ${s.sellFeePct === top ? "sell" : "buy"}`;
}
function describeAge(s, now) {
  const hours = ageInHours(s, now) ?? 0;
  if (hours < 1) return "less than an hour";
  if (hours < 48) {
    const whole = Math.floor(hours);
    return `${whole} ${whole === 1 ? "hour" : "hours"}`;
  }
  return `${Math.floor(hours / 24)} days`;
}
var CHECKS = [
  // ---------------------------------------------------------------- Security
  {
    id: "honeypot",
    name: "Honeypot",
    passLabel: "Passed the sell test",
    category: "security",
    evaluate: (s) => atLeast(s.honeypotRisk, [
      [90, {
        severity: "critical",
        points: 100,
        title: "Likely can\u2019t be sold",
        summary: "Tests suggest you could buy this token but not sell it.",
        details: tooltipFor("honeypot")
      }],
      [50, {
        severity: "warning",
        points: 30,
        title: "Selling may be blocked",
        summary: "Our sell test found signs that selling could be restricted.",
        details: tooltipFor("honeypot")
      }]
    ]),
    ifUnknown: {
      severity: "warning",
      points: 30,
      title: "Sell test couldn\u2019t run",
      summary: "We couldn\u2019t confirm that this token can be sold.",
      details: tooltipFor("honeypot")
    }
  },
  {
    id: "canTakeTokens",
    name: "Owner can change balance",
    passLabel: "Creator can\u2019t take your tokens",
    category: "security",
    evaluate: (s) => whenTrue(s.canTakeTokens, {
      severity: "critical",
      points: 60,
      title: "Creator can take your tokens",
      summary: "The creator can remove or change the tokens in your wallet.",
      details: tooltipFor("canTakeTokens")
    })
  },
  {
    id: "knownScamCreator",
    name: "Creator address",
    passLabel: "Creator has no known scams",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.knownScamCreator, {
      severity: "critical",
      points: 60,
      title: "Creator linked to scams",
      summary: "Whoever made this token has made scam tokens before.",
      details: tooltipFor("knownScamCreator")
    })
  },
  {
    id: "pause",
    name: "Transfer pausable",
    passLabel: "Trading can\u2019t be paused",
    category: "security",
    evaluate: (s) => {
      if (s.tradingPaused) {
        return {
          severity: "critical",
          points: 60,
          title: "Trading is switched off",
          summary: "Nobody can buy, sell or send this token right now.",
          details: tooltipFor("pause")
        };
      }
      return whenTrue(s.canPause, {
        severity: "warning",
        points: 15,
        title: "Trading can be paused",
        summary: "The creator can switch off trading at any time.",
        details: tooltipFor("pause")
      });
    }
  },
  {
    id: "fees",
    name: "Buy and sell tax",
    passLabel: "Low or no trading fees",
    category: "security",
    measure: describeFee,
    evaluate: (s) => atLeast(highestFee(s), [
      [30, {
        severity: "critical",
        points: 60,
        title: "Very high fees",
        summary: "The token charges {value}.",
        details: tooltipFor("fees")
      }],
      [10, {
        severity: "warning",
        points: 20,
        title: "High fees",
        summary: "The token charges {value}.",
        details: tooltipFor("fees")
      }],
      [5, {
        severity: "minor",
        points: 5,
        title: "Trading fees",
        summary: "The token charges {value}.",
        details: tooltipFor("fees")
      }]
    ])
  },
  {
    id: "mintable",
    name: "Mintable",
    passLabel: "No more tokens can be made",
    category: "security",
    evaluate: (s) => whenTrue(s.mintable, {
      severity: "warning",
      points: 25,
      title: "Creator can make more tokens",
      summary: "New tokens can be created at any time, making yours worth less.",
      details: tooltipFor("mintable")
    })
  },
  {
    id: "canFreeze",
    name: "Has blacklist",
    passLabel: "Wallets can\u2019t be frozen",
    category: "security",
    appliesTo: ["solana"],
    evaluate: (s) => whenTrue(s.canFreeze, {
      severity: "warning",
      points: 25,
      title: "Creator can freeze wallets",
      summary: "The creator can lock tokens in a wallet so they can\u2019t be sold.",
      details: tooltipFor("canFreeze")
    })
  },
  {
    id: "hasBlacklist",
    name: "Has blacklist",
    passLabel: "No blacklist",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.hasBlacklist, {
      severity: "warning",
      points: 25,
      title: "Creator can blacklist wallets",
      summary: "The creator can lock a wallet out of buying, selling, or sending.",
      details: tooltipFor("hasBlacklist")
    })
  },
  {
    id: "hasWhitelist",
    name: "Has whitelist",
    passLabel: "No whitelist",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.hasWhitelist, {
      severity: "warning",
      points: 15,
      title: "Some wallets skip the rules",
      summary: "Chosen wallets can trade when others cannot.",
      details: tooltipFor("hasWhitelist")
    })
  },
  {
    id: "feesChangeable",
    name: "Tax modifiable",
    passLabel: "Fees can\u2019t be changed",
    category: "security",
    evaluate: (s) => whenTrue(s.feesChangeable, {
      severity: "warning",
      points: 20,
      title: "Fees can be raised",
      summary: "The creator can change the trading fees whenever they like.",
      details: tooltipFor("feesChangeable")
    })
  },
  {
    id: "publicCode",
    name: "Open source",
    passLabel: "Code is public",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenFalse(s.codeVerified, {
      severity: "warning",
      points: 25,
      title: "Code isn\u2019t public",
      summary: "The token\u2019s code hasn\u2019t been published, so nobody can check it.",
      details: tooltipFor("publicCode")
    })
  },
  {
    id: "upgradeable",
    name: "Proxy contract",
    passLabel: "Code can\u2019t be replaced",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.upgradeable, {
      severity: "warning",
      points: 15,
      title: "Code can be replaced",
      summary: "The creator can swap the token\u2019s code for new code.",
      details: tooltipFor("upgradeable")
    })
  },
  {
    id: "hiddenControl",
    name: "Hidden owner",
    passLabel: "No hidden control",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.hiddenControl, {
      severity: "warning",
      points: 25,
      title: "Hidden control",
      summary: "The code hides the real owner or lets them take control back.",
      details: tooltipFor("hiddenControl")
    })
  },
  {
    id: "externalCall",
    name: "External call",
    passLabel: "No risky outside calls",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.externalCall, {
      severity: "warning",
      points: 15,
      title: "Transfer runs outside code",
      summary: "A transfer can run code that is not part of the token.",
      details: tooltipFor("externalCall")
    })
  },
  {
    id: "suspiciousFunctions",
    name: "Has suspicious functions",
    passLabel: "No suspicious functions",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.suspiciousFunctions, {
      severity: "warning",
      points: 20,
      title: "Suspicious functions",
      summary: "The contract has extra powers that honest tokens usually do not need.",
      details: tooltipFor("suspiciousFunctions")
    })
  },
  {
    id: "sellLimits",
    name: "Can\u2019t sell all",
    passLabel: "No limits on selling",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.cannotSellAll ?? s.sellLimited, {
      severity: "warning",
      points: 20,
      title: "Selling can be limited",
      summary: "You might not be allowed to sell all your tokens when you want.",
      details: tooltipFor("sellLimits")
    })
  },
  {
    id: "antiWhale",
    name: "Is anti-whale",
    passLabel: "No anti-whale limits",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.antiWhale, {
      severity: "warning",
      points: 15,
      title: "Selling or holding can be capped",
      summary: "The creator can limit how much you buy, sell, or hold.",
      details: tooltipFor("antiWhale")
    })
  },
  {
    id: "tradingCooldown",
    name: "Trading cooldown",
    passLabel: "No trading cooldown",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenTrue(s.tradingCooldown, {
      severity: "warning",
      points: 15,
      title: "Trades can be delayed",
      summary: "The creator can force a wait between transfers.",
      details: tooltipFor("tradingCooldown")
    })
  },
  {
    id: "liquidityLock",
    name: "Locked trading pool",
    passLabel: "Trading pool is locked",
    category: "security",
    measure: (s) => percent(s.liquidityLockedPct ?? 0),
    evaluate: (s) => below(s.liquidityLockedPct, [
      [50, {
        severity: "warning",
        points: 25,
        title: "Trading pool isn\u2019t locked",
        summary: "The creator could empty the pool of money that lets people sell.",
        details: tooltipFor("liquidityLock")
      }],
      [90, {
        severity: "minor",
        points: 5,
        title: "Trading pool partly locked",
        summary: "Only {value} of the trading pool is locked.",
        details: tooltipFor("liquidityLock")
      }]
    ])
  },
  {
    id: "ownership",
    name: "Ownership renounced",
    passLabel: "Creator has given up control",
    category: "security",
    appliesTo: ["evm"],
    evaluate: (s) => whenFalse(s.ownershipRenounced, {
      severity: "minor",
      points: 3,
      title: "Creator still has control",
      summary: "The creator hasn\u2019t given up control of the token\u2019s settings.",
      details: tooltipFor("ownership")
    })
  },
  {
    id: "metadataMutable",
    name: "Name and logo",
    passLabel: "Name and logo are fixed",
    category: "security",
    appliesTo: ["solana"],
    evaluate: (s) => whenTrue(s.metadataMutable, {
      severity: "minor",
      points: 3,
      title: "Name and logo can change",
      summary: "The creator can still change the token\u2019s name, symbol and image.",
      details: tooltipFor("metadataMutable")
    })
  },
  // ------------------------------------------------------------------ Market
  {
    id: "liquidity",
    name: "Trading pool size",
    passLabel: "Healthy trading pool",
    category: "market",
    measure: (s) => dollars(s.liquidityUsd ?? 0),
    evaluate: (s) => below(s.liquidityUsd, [
      [1e4, {
        severity: "warning",
        points: 20,
        title: "Tiny trading pool",
        summary: "Only {value} is available for trading, so selling could crash the price.",
        details: tooltipFor("liquidity")
      }],
      [5e4, {
        severity: "minor",
        points: 5,
        title: "Small trading pool",
        summary: "Only {value} is available for trading.",
        details: tooltipFor("liquidity")
      }]
    ])
  },
  {
    id: "tokenAge",
    name: "Token age",
    passLabel: "Not brand new",
    category: "market",
    measure: describeAge,
    evaluate: (s, now) => below(ageInHours(s, now), [
      [24, {
        severity: "minor",
        points: 5,
        title: "Brand-new token",
        summary: "It started trading {value} ago.",
        details: tooltipFor("tokenAge")
      }],
      [7 * 24, {
        severity: "minor",
        points: 2,
        title: "New token",
        summary: "It started trading {value} ago.",
        details: tooltipFor("tokenAge")
      }]
    ])
  },
  {
    id: "socials",
    name: "Website and social media",
    passLabel: "Has a website or social media",
    category: "market",
    evaluate: (s) => whenFalse(s.hasWebsiteOrSocials, {
      severity: "minor",
      points: 5,
      title: "No website or social media",
      summary: "We couldn\u2019t find a website or social accounts for this token.",
      details: tooltipFor("socials")
    })
  },
  // ----------------------------------------------------- Holders (experimental)
  {
    id: "clusters",
    name: "Linked wallets",
    passLabel: "No big groups of linked wallets",
    category: "holders",
    experimental: true,
    measure: (s) => percent(s.clusterPct ?? 0),
    evaluate: (s) => atLeast(s.clusterPct, [
      [50, {
        severity: "warning",
        points: 30,
        title: "Linked wallets hold most tokens",
        summary: "Wallets that seem to belong to the same people hold {value} of all tokens.",
        details: tooltipFor("clusters")
      }],
      [30, {
        severity: "warning",
        points: 20,
        title: "Linked wallets hold a lot",
        summary: "Wallets that seem to belong to the same people hold {value} of all tokens.",
        details: tooltipFor("clusters")
      }],
      [15, {
        severity: "minor",
        points: 5,
        title: "Some linked wallets",
        summary: "Wallets that seem to belong to the same people hold {value} of all tokens.",
        details: tooltipFor("clusters")
      }]
    ])
  },
  {
    id: "bundlers",
    name: "Coordinated buying",
    passLabel: "Little coordinated buying",
    category: "holders",
    experimental: true,
    appliesTo: ["solana"],
    measure: (s) => percent(s.bundlersPct ?? 0),
    evaluate: (s) => atLeast(s.bundlersPct, [
      [20, {
        severity: "warning",
        points: 20,
        title: "Coordinated buying at launch",
        summary: "Wallets that bought together at launch hold {value} of all tokens.",
        details: tooltipFor("bundlers")
      }],
      [5, {
        severity: "minor",
        points: 5,
        title: "Some coordinated buying",
        summary: "Wallets that bought together at launch hold {value} of all tokens.",
        details: tooltipFor("bundlers")
      }]
    ])
  },
  {
    id: "snipers",
    name: "Launch snipers",
    passLabel: "Few launch snipers",
    category: "holders",
    experimental: true,
    appliesTo: ["solana"],
    measure: (s) => percent(s.snipersPct ?? 0),
    evaluate: (s) => atLeast(s.snipersPct, [
      [20, {
        severity: "warning",
        points: 15,
        title: "Many launch snipers",
        summary: "Wallets that bought in the first minute still hold {value} of all tokens.",
        details: tooltipFor("snipers")
      }],
      [5, {
        severity: "minor",
        points: 5,
        title: "Some launch snipers",
        summary: "Wallets that bought in the first minute still hold {value} of all tokens.",
        details: tooltipFor("snipers")
      }]
    ])
  },
  {
    id: "devHoldings",
    name: "Creator balance",
    passLabel: "Creator holds a small share",
    category: "holders",
    experimental: true,
    appliesTo: ["solana"],
    measure: (s) => percent(sumDefined(s.devPct, s.insidersPct) ?? 0),
    evaluate: (s) => atLeast(sumDefined(s.devPct, s.insidersPct), [
      [15, {
        severity: "warning",
        points: 20,
        title: "Creator holds a lot",
        summary: "The creator and people linked to them hold {value} of all tokens.",
        details: tooltipFor("devHoldings")
      }],
      [5, {
        severity: "minor",
        points: 5,
        title: "Creator holds some tokens",
        summary: "The creator and people linked to them hold {value} of all tokens.",
        details: tooltipFor("devHoldings")
      }]
    ])
  },
  {
    id: "topHolders",
    name: "Holder count",
    passLabel: "Ownership is spread out",
    category: "holders",
    experimental: true,
    measure: (s) => percent(s.top10Pct ?? 0),
    evaluate: (s) => atLeast(s.top10Pct, [
      [50, {
        severity: "warning",
        points: 20,
        title: "A few wallets own most of it",
        summary: "The 10 biggest wallets own {value} of all tokens.",
        details: tooltipFor("topHolders")
      }],
      [30, {
        severity: "minor",
        points: 5,
        title: "Ownership is concentrated",
        summary: "The 10 biggest wallets own {value} of all tokens.",
        details: tooltipFor("topHolders")
      }]
    ])
  }
];

// ../trust-score-saved/src/scoring/score.ts
var BANDS = [
  { band: "low", min: 80 },
  { band: "medium", min: 40 },
  { band: "high", min: 0 }
];
var SEVERITY_CAPS = {
  critical: 39,
  warning: 79,
  minor: 100
};
var MIN_COVERAGE = 0.5;
var SEVERITY_ORDER = { critical: 0, warning: 1, minor: 2 };
function scoreToken(signals, options = {}) {
  const { includeExperimental = true, now = Date.now(), checks = CHECKS } = options;
  const issues = [];
  const passed = [];
  const notChecked = [];
  const coverage = { checked: 0, total: 0 };
  for (const check of checks) {
    const experimental = check.experimental ?? false;
    if (experimental && !includeExperimental) continue;
    if (check.appliesTo && !check.appliesTo.includes(signals.chain)) continue;
    const tier = check.evaluate(signals, now);
    if (!experimental) {
      coverage.total += 1;
      if (tier !== void 0) coverage.checked += 1;
    }
    const about = ABOUT[check.id];
    if (tier === null) {
      passed.push({ id: check.id, label: check.passLabel, experimental, about });
    } else if (tier) {
      issues.push(toIssue(check, tier, check.measure?.(signals, now)));
    } else if (check.ifUnknown) {
      issues.push(toIssue(check, check.ifUnknown));
    } else {
      notChecked.push({ id: check.id, label: check.name, experimental, about });
    }
  }
  issues.sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || b.points - a.points);
  if (coverage.total === 0 || coverage.checked / coverage.total < MIN_COVERAGE) {
    return { score: null, band: null, issues, passed, notChecked, coverage };
  }
  const deducted = issues.reduce((sum, issue) => sum + issue.points, 0);
  const cap = Math.min(100, ...issues.map((issue) => SEVERITY_CAPS[issue.severity]));
  const score = Math.max(0, Math.min(cap, 100 - deducted));
  const band = BANDS.find(({ min }) => score >= min)?.band ?? "high";
  return { score, band, issues, passed, notChecked, coverage };
}
function toIssue(check, tier, measured = "") {
  const fill = (text) => text.replaceAll("{value}", measured);
  return {
    id: check.id,
    category: check.category,
    experimental: check.experimental ?? false,
    severity: tier.severity,
    points: tier.points,
    title: fill(tier.title),
    summary: fill(tier.summary),
    details: fill(tier.details)
  };
}

// src/detect.ts
var EVM_ADDRESS = /^0x[a-fA-F0-9]{40}$/;
var SOLANA_ADDRESS = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

// src/twitter.ts
var TIMEOUT_MS = 2e4;
var TwitterError = class extends Error {
  status;
  constructor(status) {
    super(`Twitter HTTP ${status}`);
    this.status = status;
  }
};
async function getJson(path, bearer, signal) {
  const timeout = AbortSignal.timeout(TIMEOUT_MS);
  const response = await fetch(`https://api.twitter.com${path}`, {
    headers: { accept: "application/json", authorization: `Bearer ${bearer}` },
    signal: signal ? AbortSignal.any([signal, timeout]) : timeout
  });
  if (!response.ok) throw new TwitterError(response.status);
  return await response.json();
}
function tweetStats(tweet) {
  const metrics = tweet.public_metrics;
  return {
    likes: metrics?.like_count ?? 0,
    replies: metrics?.reply_count ?? 0,
    reposts: (metrics?.retweet_count ?? 0) + (metrics?.quote_count ?? 0)
  };
}
function urlsFrom(user) {
  const raw = [
    user.url,
    ...(user.entities?.url?.urls ?? []).map((item) => item.expanded_url ?? item.display_url),
    ...(user.entities?.description?.urls ?? []).map((item) => item.expanded_url ?? item.display_url)
  ];
  return [...new Set(raw.filter((url) => Boolean(url && /^https?:/i.test(url))))];
}
function mentionsFrom(user) {
  const fromEntities = (user.entities?.description?.mentions ?? []).map((item) => item.username).filter(Boolean);
  const fromAt = [...(user.description ?? "").matchAll(/@([A-Za-z0-9_]{1,15})/g)].map((match) => match[1]);
  return [...new Set([...fromEntities, ...fromAt].map((name) => name.toLowerCase()))];
}
function searchQuery(symbol, name, handle) {
  const parts = [];
  const ticker = symbol?.replace(/[^A-Za-z0-9]/g, "");
  if (ticker) parts.push(`$${ticker}`, `#${ticker}`);
  const phrase = name?.trim();
  if (phrase && phrase.length <= 40) parts.push(`"${phrase.replaceAll('"', "")}"`);
  if (parts.length === 0) return void 0;
  const exclude = handle ? ` -from:${handle}` : "";
  return `(${parts.join(" OR ")}) -is:retweet${exclude}`;
}
async function fetchProfile(handle, bearer, signal) {
  const user = await getJson(
    `/2/users/by/username/${encodeURIComponent(handle)}?user.fields=public_metrics,name,username,description,url,entities`,
    bearer,
    signal
  );
  if (!user.data?.id) return void 0;
  return {
    id: user.data.id,
    handle: user.data.username ?? handle,
    name: user.data.name,
    followers: user.data.public_metrics?.followers_count ?? 0,
    bio: user.data.description,
    urls: urlsFrom(user.data),
    mentions: mentionsFrom(user.data).filter((name) => name !== (user.data?.username ?? handle).toLowerCase())
  };
}
async function fetchTweets(userId, bearer, signal) {
  try {
    const page = await getJson(
      `/2/users/${userId}/tweets?max_results=20&exclude=retweets,replies&tweet.fields=public_metrics`,
      bearer,
      signal
    );
    return (page.data ?? []).map(tweetStats);
  } catch (error) {
    if (error instanceof TwitterError) return [];
    throw error;
  }
}
async function lookupPeople(usernames, bearer, signal) {
  const unique = [...new Set(usernames)].slice(0, 20);
  if (unique.length === 0) return [];
  try {
    const body = await getJson(
      `/2/users/by?usernames=${encodeURIComponent(unique.join(","))}&user.fields=public_metrics,username`,
      bearer,
      signal
    );
    return (body.data ?? []).map((user) => ({
      handle: user.username ?? "",
      followers: user.public_metrics?.followers_count ?? 0
    })).filter((person) => person.handle);
  } catch (error) {
    if (error instanceof TwitterError) return [];
    throw error;
  }
}
async function fetchMentions(query, bearer, signal) {
  const path = `/2/tweets/search/recent?query=${encodeURIComponent(query)}&max_results=50&tweet.fields=public_metrics,author_id&expansions=author_id&user.fields=public_metrics`;
  const page = await getJson(path, bearer, signal);
  const authors = new Map((page.includes?.users ?? []).map((user) => [user.id, user]));
  return (page.data ?? []).map((tweet) => {
    const author = tweet.author_id ? authors.get(tweet.author_id) : void 0;
    return {
      followers: author?.public_metrics?.followers_count ?? 0,
      ...tweetStats(tweet)
    };
  });
}
async function fetchTwitterBundle(input, bearer, signal) {
  const query = searchQuery(input.symbol, input.name, input.handle);
  const [profileResult, mentionResult] = await Promise.allSettled([
    input.handle ? fetchProfile(input.handle, bearer, signal) : Promise.resolve(void 0),
    query ? fetchMentions(query, bearer, signal) : Promise.resolve([])
  ]);
  if (profileResult.status === "rejected" && mentionResult.status === "rejected") {
    throw profileResult.reason;
  }
  const profile = profileResult.status === "fulfilled" ? profileResult.value : void 0;
  const [tweets, mentionedPeople] = await Promise.all([
    profile ? fetchTweets(profile.id, bearer, signal) : Promise.resolve([]),
    profile?.mentions.length ? lookupPeople(profile.mentions, bearer, signal) : Promise.resolve([])
  ]);
  return {
    profile,
    tweets,
    mentionedPeople,
    mentions: mentionResult.status === "fulfilled" ? mentionResult.value : []
  };
}
function communityFromBundle(bundle) {
  return scoreCommunity({
    official: bundle.profile ? { handle: bundle.profile.handle, name: bundle.profile.name, followers: bundle.profile.followers, tweets: bundle.tweets } : void 0,
    mentions: bundle.mentions
  });
}

// src/lookup.ts
var EVM_CHAINS = [
  { name: "Ethereum", dexScreenerId: "ethereum", network: "eth" },
  { name: "Base", dexScreenerId: "base", network: "base" },
  { name: "BNB Chain", dexScreenerId: "bsc", network: "bsc" }
];
var SOLANA_CHAINS = [{ name: "Solana", dexScreenerId: "solana", network: "sol" }];
var ALL_CHAINS = [...EVM_CHAINS, ...SOLANA_CHAINS];
var DEXSCREENER = "https://api.dexscreener.com";
var GOPLUS = "https://api.gopluslabs.io";
var COINGECKO = "https://api.coingecko.com";
var INSIGHTX = "https://api.insightx.network";
var TIMEOUT_MS2 = 2e4;
var COINGECKO_PLATFORM = {
  eth: "ethereum",
  base: "base",
  bsc: "binance-smart-chain",
  sol: "solana"
};
var NETWORK_CHAIN = {
  eth: EVM_CHAINS[0],
  base: EVM_CHAINS[1],
  bsc: EVM_CHAINS[2],
  sol: SOLANA_CHAINS[0]
};
var LookupError = class extends Error {
  reason;
  searched;
  constructor(reason, searched = []) {
    super(`Token lookup failed: ${reason}`);
    this.name = "LookupError";
    this.reason = reason;
    this.searched = searched;
  }
};
var HttpError = class extends Error {
  status;
  constructor(status) {
    super(`HTTP ${status}`);
    this.status = status;
  }
};
async function getJson2(url, signal, headers) {
  const timeout = AbortSignal.timeout(TIMEOUT_MS2);
  const response = await fetch(url, {
    headers: { accept: "*/*", ...headers },
    signal: signal ? AbortSignal.any([signal, timeout]) : timeout
  });
  if (!response.ok) throw new HttpError(response.status);
  return await response.json();
}
function chainsFor(address, hint) {
  if (hint) return [NETWORK_CHAIN[hint]];
  if (EVM_ADDRESS.test(address)) return EVM_CHAINS;
  if (SOLANA_ADDRESS.test(address)) return SOLANA_CHAINS;
  return [];
}
function goPlusUrl(chain, address) {
  return chain.network === "sol" ? `${GOPLUS}/api/v1/solana/token_security?contract_addresses=${address}` : `${GOPLUS}/api/v1/token_security/${goPlusChainId(chain.network)}?contract_addresses=${address}`;
}
async function fetchGoPlus(chain, address, signal) {
  const body = await getJson2(goPlusUrl(chain, address), signal);
  if (body.code !== 1) throw new HttpError(body.code ?? 500);
  const token = tokenFromGoPlus(body.result, address);
  if (!token) throw new HttpError(404);
  return token;
}
var deepestPool = (pairs) => Math.max(0, ...pairs.map((pair) => pair.liquidity?.usd ?? 0));
async function resolveTokenAddress(target, signal) {
  if (target.kind === "token") return { address: target.address, chainHint: target.chainHint };
  const chainId = ALL_CHAINS.find((chain) => chain.network === target.chainHint)?.dexScreenerId ?? target.chainHint;
  if (chainId) {
    try {
      const body = await getJson2(
        `${DEXSCREENER}/latest/dex/pairs/${chainId}/${target.address}`,
        signal
      );
      const pair = body.pairs?.[0];
      const token = pair?.baseToken?.address;
      if (token && (EVM_ADDRESS.test(token) || SOLANA_ADDRESS.test(token))) {
        return { address: token, chainHint: target.chainHint };
      }
    } catch (error) {
      if (!(error instanceof HttpError)) throw error;
    }
  }
  return { address: target.address, chainHint: target.chainHint };
}
async function scanTarget(target, keys, signal) {
  const resolved = await resolveTokenAddress(target, signal);
  const address = resolved.address;
  const chains = chainsFor(address, resolved.chainHint);
  if (chains.length === 0) throw new LookupError("invalid");
  const listings = await Promise.allSettled(
    chains.map(
      (chain2) => getJson2(`${DEXSCREENER}/token-pairs/v1/${chain2.dexScreenerId}/${address}`, signal)
    )
  );
  signal?.throwIfAborted();
  const found = chains.flatMap((chain2, i) => {
    const listing = listings[i];
    return listing.status === "fulfilled" && Array.isArray(listing.value) && listing.value.length > 0 ? [{ chain: chain2, pairs: listing.value }] : [];
  });
  if (found.length === 0) {
    throw new LookupError(listings.some((listing) => listing.status === "rejected") ? "unavailable" : "not-found", chains);
  }
  const { chain, pairs } = found.reduce((best, next) => deepestPool(next.pairs) > deepestPool(best.pairs) ? next : best);
  const identity = tokenFromDexScreener(pairs, address);
  const twitter = twitterHandleFromDexScreener(pairs);
  const [scan, holders, twitterBundle, gecko] = await Promise.allSettled([
    fetchGoPlus(chain, address, signal),
    keys.insightx ? getJson2(`${INSIGHTX}/dex-metrics/v1/${chain.network}/${address}`, signal, {
      "X-API-Key": keys.insightx
    }) : Promise.reject(new HttpError(401)),
    keys.twitter ? fetchTwitterBundle({ handle: twitter, name: identity.name, symbol: identity.symbol }, keys.twitter, signal) : Promise.reject(new TwitterError(401)),
    getJson2(`${COINGECKO}/api/v3/coins/${COINGECKO_PLATFORM[chain.network]}/contract/${address}`, signal)
  ]);
  signal?.throwIfAborted();
  const failures = [];
  if (scan.status === "rejected") failures.push(failureFrom("scan", scan.reason));
  if (holders.status === "rejected") failures.push(failureFrom("holders", holders.reason));
  if (twitterBundle.status === "rejected") failures.push(failureFrom("community", twitterBundle.reason));
  const signals = buildSignals(chain.network, {
    dexScreenerPairs: pairs,
    goPlus: scan.status === "fulfilled" ? scan.value : void 0,
    insightXDexMetrics: holders.status === "fulfilled" ? holders.value : void 0
  });
  const bundle = twitterBundle.status === "fulfilled" ? twitterBundle.value : void 0;
  return {
    address,
    chain,
    ...identity,
    twitter,
    community: bundle ? communityFromBundle(bundle) : scoreCommunity({}),
    foundation: scoreFoundation({
      launchedAt: signals.launchedAt,
      websites: websitesFromDexScreener(pairs),
      bio: bundle?.profile?.bio,
      urls: bundle?.profile?.urls,
      mentionedPeople: bundle?.mentionedPeople,
      exchangeHints: gecko.status === "fulfilled" ? exchangeIdsFromCoinGecko(gecko.value) : []
    }),
    failures,
    report: scoreToken(signals)
  };
}
function failureFrom(source, reason) {
  if (reason instanceof HttpError || reason instanceof TwitterError) return { source, status: reason.status };
  return { source };
}
function scanErrorMessage(error) {
  if (!(error instanceof LookupError)) return "Something went wrong. Please try again.";
  if (error.reason === "invalid") return "That doesn\u2019t look like a token address.";
  if (error.reason === "not-found") {
    const chains = new Intl.ListFormat("en-GB", { type: "disjunction" }).format(error.searched.map((chain) => chain.name));
    return `We couldn\u2019t find this token on ${chains}.`;
  }
  return "We couldn\u2019t reach the market data service. Try again in a minute.";
}

// src/background.ts
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "scan") return;
  void (async () => {
    try {
      const result = await scanTarget(message.target, await loadKeys());
      const response = { ok: true, result };
      sendResponse(response);
    } catch (error) {
      const response = { ok: false, message: scanErrorMessage(error) };
      sendResponse(response);
    }
  })();
  return true;
});
